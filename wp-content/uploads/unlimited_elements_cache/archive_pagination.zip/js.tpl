{% if show_icons == "true" %}
{{ ucfunc("put_docready_start") }}
		
  var objWidget = jQuery("#{{uc_id}}");
 
  function appendIcons(){
    
    var objNextBtn = objWidget.find(".next");
    var iconNextSelector = ".archive_pagination-next-icon";
    var objNextIcon = objWidget.find(iconNextSelector);
    
    if(objNextBtn && objNextBtn.length > 0){
      var iconHTML = objNextIcon.html();
      var objChildIcon = objNextIcon.find(iconNextSelector);
      
      if(!objChildIcon || objChildIcon.length == 0)
      objNextBtn.append(objNextIcon);
    }
    
    var objPrevBtn = objWidget.find(".prev");
    var iconPrevSelector = ".archive_pagination-prev-icon";
    var objPrevIcon = objWidget.find(iconPrevSelector);
    
    if(objPrevBtn && objPrevBtn.length > 0){
      var iconHTML = objPrevIcon.html();
      var objChildIcon = objPrevBtn.find(iconPrevSelector);
      
      if(!objChildIcon || objChildIcon.length == 0)
      objPrevBtn.prepend(objPrevIcon);
    }
  }
 
  {% if uc_inside_editor == "yes" %}
    appendIcons();
  {% endif %}
  
  //if no ajax connection to grid just add icon on page load
  if(jQuery.isEmptyObject(objWidget.data())){
    appendIcons();
  }
 
  objWidget.on("uc_ajax_reloaded", function(){
    appendIcons();
  });   
   
  objWidget.on("init_filter", function(){
    appendIcons();
  });
   
{{ ucfunc("put_docready_end") }}
{% endif %}