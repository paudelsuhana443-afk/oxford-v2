<div id="{{uc_id}}" class="archive_pagination uc-filter-pagination {%if force_non_ajax == "true"%}uc-no-ajax{%endif%}">
  {% set widget_data = get_data() %}
  {{putPagination(widget_data)}}
  <div class="archive_pagination-icons">
    <span class="archive_pagination-next-icon">{{next_icon_html|ucsafe|raw}}</span>
    <span class="archive_pagination-prev-icon">{{prev_icon_html|ucsafe|raw}}</span>
  </div>
</div>